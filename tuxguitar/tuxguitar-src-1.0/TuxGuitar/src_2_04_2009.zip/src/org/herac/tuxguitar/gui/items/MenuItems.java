package org.herac.tuxguitar.gui.items;

public interface MenuItems extends ItemBase{
	public void showItems();
}
