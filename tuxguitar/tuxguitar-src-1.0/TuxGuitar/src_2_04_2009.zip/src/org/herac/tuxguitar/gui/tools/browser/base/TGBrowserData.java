package org.herac.tuxguitar.gui.tools.browser.base;

public interface TGBrowserData {
	
	public String getTitle();
	
	public String toString();
	
}
