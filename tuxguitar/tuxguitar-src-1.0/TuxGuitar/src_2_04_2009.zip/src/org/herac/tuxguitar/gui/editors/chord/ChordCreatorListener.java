package org.herac.tuxguitar.gui.editors.chord;

import java.util.List;

public interface ChordCreatorListener {
	
	public void notifyChords(ChordCreatorUtil process, List chords);
	
}
