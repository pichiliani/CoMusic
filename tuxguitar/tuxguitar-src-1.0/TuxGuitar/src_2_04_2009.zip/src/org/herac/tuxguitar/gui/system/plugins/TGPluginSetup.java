package org.herac.tuxguitar.gui.system.plugins;

import org.eclipse.swt.widgets.Shell;

public interface TGPluginSetup {
	
	public void setupDialog(Shell parent);
	
}
