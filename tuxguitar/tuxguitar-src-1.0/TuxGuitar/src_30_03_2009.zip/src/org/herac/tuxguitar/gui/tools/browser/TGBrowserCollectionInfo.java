package org.herac.tuxguitar.gui.tools.browser;

public class TGBrowserCollectionInfo {
	
	private String type;
	private String data;
	
	public TGBrowserCollectionInfo(){
		super();
	}
	
	public String getData() {
		return this.data;
	}
	
	public void setData(String data) {
		this.data = data;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
}
