// $Id: Wizard.java,v 1.7 2004/03/06 21:16:21 mvw Exp $
// Copyright (c) 1996-99 The Regents of the University of California. All
// Rights Reserved. Permission to use, copy, modify, and distribute this
// software and its documentation without fee, and without a written
// agreement is hereby granted, provided that the above copyright notice
// and this paragraph appear in all copies.  This software program and
// documentation are copyrighted by The Regents of the University of
// California. The software program and documentation are supplied "AS
// IS", without any accompanying services from The Regents. The Regents
// does not warrant that the operation of the program will be
// uninterrupted or error-free. The end-user understands that the program
// was developed for research purposes and is advised not to rely
// exclusively on the program for any reason.  IN NO EVENT SHALL THE
// UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
// THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
// PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
// CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
// UPDATES, ENHANCEMENTS, OR MODIFICATIONS. 


// File: Wizard.java
// Classes: Wizard
// Original Author: jrobbins@ics.uci.edu
// $Id: Wizard.java,v 1.7 2004/03/06 21:16:21 mvw Exp $

package org.herac.tuxguitar.gui;

import javax.swing.JOptionPane;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;


import javax.swing.event.EventListenerList;
import javax.xml.parsers.ParserConfigurationException;
import javax.swing.Action;
import javax.swing.Icon;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

//Estes imports s�o �teis para a colabora��o!
import java.net.*;
import java.io.*;
import java.util.*;
import java.awt.*;

import java.util.Collection;


public class ClienteRecebe extends Thread 
{
	private Socket socket;
	private DataInputStream is;
	// private Editor e;
	
	public ClienteRecebe(Socket s,DataInputStream i) {
		this.socket = s;
		this.is = i;
	}
	
    public void run ()  {
        
    	try {

            boolean clientTalking = true;
            
            //a loop that reads from and writes to the socket
            while (clientTalking) {
            	
            	byte[] clientObject = new byte[8192];
            	//get what client wants to say...
                
            	this.is.read(clientObject);
            	
            	String msg = new String(clientObject);
            	
            	String [] dados = msg.split(";");

            	String nomeEvento = dados[dados.length -1];
            	
               	if (nomeEvento.startsWith("PROT_atualiza_modelo_cliente"))
            	{
               		/*
                    ArgoDiagram d_atual = (ArgoDiagram) ProjectManager.getManager().getCurrentProject().getActiveDiagram();
                    // Aqui vou fazer uma varredura do diagrama atual
                    
                    // MostraDiagrama(d_atual,"Diagrama Atual");
                    
                    ArrayList lista = ((ArrayList) o);
                    
                    // Faz o parser dos dados no formato XMI
                    parseXMI((String) lista.get(0));
                    ArgoDiagram d_recebido = parsePGML((String) lista.get(1));
                    
                    // Seta o diagrama ativo, para evitar problemas
                    ProjectManager.getManager().getCurrentProject().setActiveDiagram(d_atual);
                    
                    if (d_recebido != null)
                    {
                    	
                        // MostraDiagrama(d_recebido,"Diagrama Recebido");
                    	
//                    	 Aqui � feito o 'merge' entre o modelo que se est� trabalhando
                    	// e o modelo que veio pela colabora��o
                    	
                    	
                        ArrayList Fs = NovasFigs(d_atual,d_recebido);

                        for(int i= 0;i<Fs.size();i++)
                        {
                        	 Fig f = (Fig) Fs.get(i); 
                    	    
                		    // Aqui chamo a procedure que adiciona a fig no modelo 	
                		    AdicionaNoDiagrama(f);
                        }
                        
                                            
                    }
                    else 
                    {
                    	System.out.println("N�o pode criar o diagrama!");
                    }
               		*/
            	}
                
               	if (nomeEvento.startsWith("PROT_atualiza_modelo_cliente_inicial"))
            	{
               		/*
               		try 
        			{
        				
               			int i;

               				Editor e;
               				
               				e = Globals.curEditor();
               				
               				// Preciso remontar a estrutura. O primeiro passo eh 
               				//  gravar o arquivo em um local e depois carreg�-lo 

            				ArrayList li = ((ArrayList) o);
                			// byte[] dados_binarios = new byte[(int) li.get(0) ];
                			
                			// File f = new File("c:\\teste" + e.clienteEnvia.getLogin() + ".zargo");
            				File f = new File("c:\\teste1.zargo");
                			FileOutputStream fos = new FileOutputStream(f);
               			
                			
      					    fos.write( (byte[]) li.get(0) );
      					  
                			fos.close();
                			
                			// Agora vou fazer o load deste arquivo
                			// URL end = new URL("file:/C:/teste1.zargo");
                			URL end = Util.fileToURL(f);
                			
                			Project pp = ProjectManager.getManager().loadProject(end);
               			
                			ProjectManager.getManager().setCurrentProject(pp,true);
                			
                			// Depois de carregado o modelo eu preciso atribuir os ID's globais
                			// para cada um dos elementos que existe no modelo
                
                			// NOVA IMPLEMENTACAO: Verificando cada elemento de cada diagrama
                			Object obj = list.get(2);
                			ArrayList IdsIniciais = ((ArrayList) obj);

                			Vector diagrams = pp.getDiagrams();
        
                			if (diagrams != null && !diagrams.isEmpty()) 
                			{
            	
				            	ArgoDiagram dd = (ArgoDiagram) pp.getDiagrams().get(0);
				            	
				            	// pp.setActiveDiagram(dd);
				            	
				            	// System.out.println("Diagrama:" +dd);
				            	
				            	Iterator it = dd.getNodes().iterator();
				                while (it.hasNext()) 
				                {
				                    Object ele = it.next();
				                    
				                    // System.out.println("Elemento:" +ele);	
				                    
				                    if(dd.presentationFor(ele) instanceof Fig)
				                    {
				                    	Fig ff = dd.presentationFor(ele);
				                    	
				                    	// System.out.println("Fig:" +ff);
					                	
				                    	for(int j=0;j<IdsIniciais.size();j++)
		                			    {
		                					String dados[] = (String []) IdsIniciais.get(j);
		 
		                					// Se achou o elemento coloca o seu ID global
		                					if(dados[0].equals( ff.classNameAndBounds()))
		                					{
		                						ff.setGlobalID( Integer.parseInt(dados[1]));
		                					}
		                			    }
				                    }
				                    
				                   
				                }
                
                			}
                			
                		// As linhas abaixo s�o para fazer o refresh do painel de navega��o	
                		ProjectBrowser.getInstance().setTitle(pp.getName());
                		
                        // Designer.TheDesigner.setCritiquingRoot(pp);
                		
              			// Agopra atualiza os pain�is!
                		// TargetManager.getInstance().setTarget(pp.getInitialTarget());
                		
                		// Aqui que � feita a atualiza��o do painel de navegacao!
                		ExplorerEventAdaptor.getInstance().structureChanged();
                		
                			
            			}
            			catch (Exception e) 
            			{
                        	 e.printStackTrace();
                        }   
            			*/
            	}
               	
               	
               	// Recebeu uma mensagem de chat!
               	if (nomeEvento.startsWith("PROT_chat_msg"))
            	{
               		/*
               		ProjectBrowser.getInstance().getStatusBar().showStatusBlink("Nova mensagem de chat!",(Color) list.get(2));
               		
               		TabCht t = (TabCht)	ProjectBrowser.getInstance().getNamedTab("Chat");
        			t.setTexto((String) o, (Color) list.get(2));
        			*/

            	}

//              Recebeu a notifica��o que algum cliente entrou na da sess�o!
               	if (nomeEvento.startsWith("PROT_inicio_sessao"))
            	{
               		/*
               		ProjectBrowser.getInstance().getStatusBar().showStatusBlink("Usu�rio " + ((String) o) + " entrou na sess�o.");
               		*/
            	}

               	
//              Recebeu a notifica��o que algum cliente saiu da sess�o!
               	if (nomeEvento.startsWith("PROT_fim_sessao"))
            	{
               		/*
               		ProjectBrowser.getInstance().getStatusBar().showStatusBlink("Usu�rio " + ((String) o) + " saiu da sess�o.");
               		*/
            	}
               	

                // Esta a��o foi removida para a experi�ncia
               	/* if (nomeEvento.equals("ActionDeleteFromDiagram-actionPerformed"))
                	ActionDeleteFromDiagram.SINGLETON.actionPerformedImpl((ActionEvent) o); */
                
                if (nomeEvento.startsWith("PROT_remove_elemento"))
                {
                	/* 
                	ActionRemoveFromModel.SINGLETON.actionPerformedImpl((ArrayList) o);
                	*/
                }
                
               	if (nomeEvento.startsWith("SEL_"))
            	{
               		/*
               		nomeEvento = nomeEvento.substring(4,nomeEvento.length());
               		
               		SelecionaTool(nomeEvento,o,false);
               		*/
                    
            	}
               	                
                if (clientObject == null) 
                    clientTalking = false;
            }
           	
            } catch (Exception e) {
            	// Retirado para evitar mostrar o erro da desconex�o!
            	// e.printStackTrace();
            }    	
    }
    
       
}

