package org.herac.tuxguitar.gui.tools.browser;

public interface TGBrowserFactoryHandler {
	
	public void notifyAdded();
	
	public void notifyRemoved();
	
}
