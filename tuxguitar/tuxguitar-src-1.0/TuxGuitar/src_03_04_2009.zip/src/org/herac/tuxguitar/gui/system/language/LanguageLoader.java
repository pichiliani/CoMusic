package org.herac.tuxguitar.gui.system.language;

public interface LanguageLoader {
	
	public void loadProperties();
	
}
