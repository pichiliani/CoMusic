package org.herac.tuxguitar.gui.system.icons;

public interface IconLoader {
	
	public void loadIcons();
	
}
