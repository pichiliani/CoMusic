package org.herac.tuxguitar.gui;

public class TGMain {
	
	public static void main(String[] args){
		TuxGuitar.instance().displayGUI(args);
		System.exit(0);
	}
	
}
